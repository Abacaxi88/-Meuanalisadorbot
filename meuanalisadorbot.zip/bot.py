import telebot
import requests
from bs4 import BeautifulSoup
from time import sleep

# Substitua pelo seu token
TOKEN = 'YOUR_BOT_TOKEN'
bot = telebot.TeleBot(TOKEN)

# Função de scraping para buscar dados de jogos
def buscar_dados_partida():
    url = 'https://www.flashscore.com.br/esoccer/'  # URL do Flashscore Esoccer
    response = requests.get(url)
    soup = BeautifulSoup(response.content, 'html.parser')

    # Exemplo: Buscando os times e horário
    jogos = soup.find_all('div', class_='event__match')  # Ajuste conforme necessário
    partidas = []

    for jogo in jogos:
        try:
            time_casa = jogo.find('span', class_='event__team--home').text.strip()
            time_fora = jogo.find('span', class_='event__team--away').text.strip()
            horario = jogo.find('div', class_='event__time').text.strip()

            # Adicionando as informações da partida em um dicionário
            partidas.append({
                'time_casa': time_casa,
                'time_fora': time_fora,
                'horario': horario
            })
        except AttributeError:
            continue  # Ignora se os dados da partida estiverem faltando

    return partidas

# Função para enviar a análise detalhada
@bot.message_handler(commands=['analise'])
def analisar(message):
    bot.send_message(message.chat.id, "Analisando a partida... Aguarde um momento.")
    sleep(5)  # Simulando tempo de análise
    partidas = buscar_dados_partida()

    for partida in partidas:
        analise = f"""
        **Jogo:** {partida['time_casa']} vs {partida['time_fora']}
        **Horário:** {partida['horario']}
        -----------------------------------------
        **Resultado esperado:** A partida tem grandes chances de ser equilibrada. {partida['time_casa']} possui uma leve vantagem, mas {partida['time_fora']} pode surpreender.
        """

        bot.send_message(message.chat.id, analise)

# Comando de boas-vindas
@bot.message_handler(commands=['start'])
def welcome(message):
    bot.send_message(message.chat.id, "Olá! Eu sou o Meuanalisadorbot. Estou aqui para analisar partidas de eSoccer! Use /analise para começar a análise de um jogo.")

# Comando para tratamento de mensagens não reconhecidas
@bot.message_handler(func=lambda message: True)
def echo_all(message):
    bot.send_message(message.chat.id, "Comando não reconhecido. Use /start para começar.")

if __name__ == "__main__":
    bot.polling(none_stop=True)
