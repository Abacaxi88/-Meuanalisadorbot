# MeuanalisadorBot - Analisador de Partidas de eSoccer

Este é um bot de Telegram que analisa partidas de eSoccer e fornece uma análise detalhada com base nos dados de jogos de esportes virtuais.

## Como rodar o bot

### Passo 1: Configurar o Token do Bot
Substitua o valor de `YOUR_BOT_TOKEN` no arquivo `bot.py` pelo seu token do bot.

### Passo 2: Instalar as dependências
Execute o seguinte comando para instalar as dependências:
```
pip install -r requirements.txt
```

### Passo 3: Rodar o Bot
Inicie o bot com o comando:
```
python bot.py
```

Agora, o bot estará funcionando e respondendo aos comandos no Telegram!
