
import telebot
from scraper import get_best_match
import time

TOKEN = '7535321372:AAEJE01dWeIpo-uxf9vNW9BDb5OUpY4rW2E'
bot = telebot.TeleBot(TOKEN)

CHAT_ID = 5284117781  # ID fornecido

def send_best_match():
    while True:
        match_info = get_best_match()
        bot.send_message(CHAT_ID, match_info)
        time.sleep(300)  # 5 minutos

@bot.message_handler(commands=['start'])
def start(message):
    bot.send_message(message.chat.id, "Bot de análise de eSoccer iniciado! A cada 5 minutos enviaremos a melhor partida!")

if __name__ == "__main__":
    import threading
    threading.Thread(target=send_best_match).start()
    bot.polling(none_stop=True)
