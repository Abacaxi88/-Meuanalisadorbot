
def get_best_match():
    # Simulando informações reais que serão buscadas futuramente por scraping
    return ("Partida: Team A vs Team B\n"
            "Jogadores: Player1 vs Player2\n"
            "Horário: 20:00\n"
            "Probabilidade de Gols:\n"
            "- Team A: 70% (Confiança Alta)\n"
            "- Team B: 65% (Confiança Média)")
